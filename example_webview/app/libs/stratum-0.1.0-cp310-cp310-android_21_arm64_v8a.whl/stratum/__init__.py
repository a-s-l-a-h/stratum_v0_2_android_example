# stratum — Python bridge to Android native API
from . import _stratum as _core
import importlib
import sys
import os

# --- Core Re-exports ---
def getActivity():
    """Return the current Android Activity. Call inside onCreate()."""
    return _core.getActivity()

def setContentView(activity, view):
    """Set the root view. Equivalent to Activity.setContentView(view)."""
    return _core.setContentView(activity, view)

def cast_to(obj, cls_name):
    """
    Cast a StratumObject to a specific Stratum wrapper class.
    cls_name should be the fully qualified java name (e.g. "android.hardware.camera2.CameraManager")
    or the stratum class name (e.g. "android.view.Surface").
    """
    safe_name = cls_name.replace(".", "_").replace("$", "_")
    target_cls = getattr(_core, safe_name, None)
    if target_cls is not None and hasattr(target_cls, "_stratum_cast"):
        return target_cls._stratum_cast(obj)
    return _core.cast_to(obj, cls_name)

def wrap_surface(obj):
    """Wrap a SurfaceTexture/Surface StratumObject into a StratumSurface."""
    return _core.wrap_surface(obj)

def remove_callback(key):
    """Remove a stored callback."""
    return _core.remove_callback(key)

def __getattr__(name):
    """Lazy loading for dynamically generated classes."""
    attr = getattr(_core, name, None)
    if attr is not None:
        return attr
    # If not found in _core, it might be a generated class we need to import
    # from its package's __init__.py.
    # This part might need refinement depending on how deeply nested packages are handled.
    # For now, we'll raise AttributeError to indicate it's not directly available.
    raise AttributeError(f"module 'stratum' has no attribute {name!r}")

def _auto_register_lifecycle():
    """
    Scans main.py for onCreate / onResume / onPause / onStop / onDestroy
    and registers them via set_lifecycle_callback.
    """
    try:
        main = sys.modules.get("main")
        if main is None:
            main = importlib.import_module("main")
    except ImportError as e:
        import traceback
        print(f"Stratum: _auto_register_lifecycle: could not import main: {e}")
        traceback.print_exc()
        return

    registered = []
    for name in ("onCreate", "onResume", "onPause", "onStop", "onDestroy"):
        fn = getattr(main, name, None)
        if callable(fn):
            _core.set_lifecycle_callback(name, fn)
            registered.append(name)

    print(f"Stratum: registered lifecycle callbacks: {registered}")
    if "onCreate" not in registered:
        print("Stratum: WARNING — no onCreate found in main.py!")
        print("         Make sure you define:  def onCreate(): ...")


# --- Expose generated classes and factories ---
# This section is dynamically populated by Stage 09's wheel building process
# based on the __init__.py files generated within each package.
# However, for direct access during development and immediate import,
# we add the commonly used ones here.

# Commonly used classes and factory functions
try:
    # Explicitly import common ones that are likely to be used directly
    # This makes them available without needing __getattr__ lookup for common cases.
    from ._stratum import (
        android_app_Activity,
        android_view_View,
        android_view_ViewGroup,
        android_widget_Button,
        android_widget_TextView,
        android_widget_EditText,
        android_graphics_SurfaceTexture,
        java_util_ArrayList, # <-- This is the crucial addition
        create_android_view_TextureView,
        create_android_view_View,
        create_android_view_ViewGroup,
        create_android_widget_Button,
        create_android_widget_TextView,
        create_android_widget_EditText,
        create_android_graphics_SurfaceTexture,
    )
except ImportError:
    # If these are not directly available, __getattr__ will be tried later,
    # but it's better to have them explicitly imported for clarity and performance.
    pass

# Auto-register lifecycle callbacks when the stratum package is first imported
# This should happen early in the app's lifecycle.
try:
    _auto_register_lifecycle()
except Exception:
    # If _auto_register_lifecycle itself fails, log it but don't crash import.
    # The user will see errors when they try to use lifecycle methods.
    import traceback
    print("Stratum: ERROR during automatic lifecycle registration!")
    traceback.print_exc()
